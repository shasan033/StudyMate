package exceptions;

public class NoAssignmentExistsException extends Exception {

    public NoAssignmentExistsException() {}
}
