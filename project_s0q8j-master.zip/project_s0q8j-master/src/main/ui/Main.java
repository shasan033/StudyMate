package ui;

// Main class that runs application
public class Main {
    public static void main(String[] args) {
        //new StudyMateApp();
        new StudyMateAppUI();
    }
}
